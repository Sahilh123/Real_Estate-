#include <iostream>
#include <string.h>
#include "property.h"
#include "apartment.h"
#include "deluxe_apartment.h"

using std::cin;
using std::cout;
using std::endl;

namespace example
{
	deluxe_apartment::deluxe_apartment()
	{
		input_apartment();
		price = 5000000 *apart_number;
		display(prop_name, "Deluxe Apartment", prop_id, price);
	}
}

