#include<iostream>
#include<string.h>
#include"property.h"
#include"land.h"
#include"apartment.h"
#include"shop.h"
#include"bungalow.h"
#include "single_apartment.h"
#include "deluxe_apartment.h"
#include "luxury_apartment.h"

using std::cout;
using std::cin;
using std::endl;
using std::string;

using namespace example;

int main()
 {
	string name ,address;
 	long int mobile;
	cout<<"\n####*****************************************************####\n\n";
	cout<<"\n !!*** WELCOME TO LUCKNOW KE NAWAB'S REAL ESTATE MANAGEMENT SYSTEM ***!! \n";
	cout<<"\n";
	cout<<"\n Enter your Details\n";
	cout<<"\n Enter your Name: ";
	getline(cin,name);
	cout<<"\n Enter the Address: ";
	getline(cin,address);
	cout<<"\n Enter your mobile no: ";
	cin>>mobile;

	int choice;

	cout<<"###**********************************###";
	cout<<"\n *****BUYING COST OF PROPERTY***** \n";
	cout<<"\n * For land it is 2500 per sq feet";
	cout<<"\n * For shops it is 5000 sq feet";
	cout<<"\n * For bunglow it Rs. 7500000";
	cout<<"\n * For single apartment it is Rs. 3500000";
	cout<<"\n * For deluxe apartment it is Rs. 5000000";
	cout<<"\n * For luxury apartment it is Rs. 6500000";
	cout<<"\n###*********************************###\n\n";

 
	do
  	{
		land l; shop s; bungalow b;
  		cout<<"\n Press 1 for Land";
  		cout<<"\n Press 2 for Shops";
  		cout<<"\n Press 3 for Bunglow";
  		cout<<"\n Press 4 for Apartments";
  		cout<<"\n Press 5 to Exit";
  		cout<<"\n\n Enter your Choice:\t";
  		cin>>choice;
  		
		switch(choice)
  		{
 		case 1:		
		l.input_land();
		break;

 		case 2:		
		s.input_shop();
		break;

 		case 3:		
		b.input_bungalow();
 		break;

 		case 4:
		int apart_choice;
 		cout << "Select the type of apartment\n";
		cout << "Press 1 for Single Apartment.\n";
		cout << "Press 2 for Deluxe Apartment.\n";
		cout << "Press 3 for Luxury Apartment.\n";
		cin >> apart_choice;
		switch(apart_choice)
  		{
 			case 1: 			
			single_apartment();
			break;
			case 2: 			
			deluxe_apartment();
			break;
	 		case 3: 			
			luxury_apartment();
 			break;
		}

 		case 5:
 		cout<<"\n * Thanks for visting us *\n";
 		break;
 		default:
 		cout<<"\n Wrong Choice;\t Try Again";
 		}
 	}
 	while (choice!=5);
	
	cout<<"\n\n BYE BYE ";
	cout<<"\n Have a nice day\n";
	cout<<"####********************************************************####"<<endl;
	return(0);
}
