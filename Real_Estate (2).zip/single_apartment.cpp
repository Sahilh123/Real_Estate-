#include <iostream>
#include <string.h>
#include "property.h"
#include "apartment.h"
#include "single_apartment.h"

using std::cin;
using std::cout;
using std::endl;

namespace example
{
	single_apartment::single_apartment()
	{
		input_apartment();
		price = 3500000 *apart_number;
		display(prop_name, "Single Apartment", prop_id, price);
	}
}

