#include <iostream>
#include<string.h>
#include "property.h"
#include "land.h"

using std::cin;
using std::cout;
using std::endl;

namespace example
{
	void land::input_land()
	{
		cout << "Enter the name of the land: ";
		cin >> prop_name;
		cout << endl;
		cout << "Enter the land ID: ";
		cin >> prop_id;
		cout << endl;
		cout << "Enter the dimensions of the land: ";
		cin >> landdimension1 >> landdimension2;
		cout << endl;
		price = landdimension1*landdimension2*2500;
		display(prop_name, "Land", prop_id, price);
	}
}